#import multiplication

def sum(a, b):
    return a + b


class addition:
    def sum(self, a, b):
        print("func inside class")
        return a + b


#print(multiplication.multiply(2, 3))
