def multiply(a,b):
    return a*b

print("executing multiplication module")