def sub(a,b):
    return a-b

print("executing subraction module", __name__)