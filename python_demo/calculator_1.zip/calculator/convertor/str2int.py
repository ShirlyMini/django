def srt_to_int(str):
    return(int(str))